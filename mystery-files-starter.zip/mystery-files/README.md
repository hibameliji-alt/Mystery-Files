# Mystery Files

A responsive, browser-based detective puzzle game with three original fictional cases.

## Run locally
1. Download `index.html`.
2. Open it in a browser. No build tools or dependencies are required.

## Deploy with GitHub + Vercel
1. Create a GitHub repository named `mystery-files` (lowercase, no spaces).
2. Add `index.html` to the repository root and commit it.
3. In Vercel, choose **Add New → Project**, import the `mystery-files` repository.
4. Set **Framework Preset** to `Other`.
5. Leave **Build Command** blank/disabled and **Output Directory** blank or `.` if required by the interface.
6. Click **Deploy**. Vercel serves `index.html` as a static site.

## Features
- Responsive layouts for phone, tablet, and desktop
- Three fictional cases, each with evidence, suspects, and a puzzle
- Clue inspection, suspect selection, hint button, puzzle validation, accusation flow
- Local progress saving with XP and detective ranks
- No external libraries or API keys

## Notes
Progress is saved in the browser on the current device using localStorage. It does not sync between devices or accounts. This is a front-end prototype; there is no backend, login, online leaderboard, or payment system yet.
